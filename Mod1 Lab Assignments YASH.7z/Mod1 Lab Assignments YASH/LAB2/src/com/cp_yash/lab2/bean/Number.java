package com.cp_yash.lab2.bean;

public class Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(Integer.parseInt(args[0])>=0)
			System.out.println("Positive");
		else
			System.out.println("Negative");

	}

}
