package com.cp_yash.lab2.bean;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Details obj1=new Details();
		Details obj2=new Details("Divya","Bharati",'F');
		System.out.println(obj2.toString());
		

	}

}
