package com.cp_yash.lab5.bean;

public enum Gender {
	M,F

}
