package com.cp_yash.lab4.bean;

import com.cp_yash.lab2.bean.Details;

public class Person_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj1=new Person();
		Person obj2=new Person("Divya","Bharati",'F',"9634563920");
		System.out.println(obj2.toString());

	}

}
