package com.cp_yash.prog1.bean;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class TestingProbleam1 {

	@Test
	public void checkConstructorWorking() {
		Date date = new Date(11, 12, 2000);
		String s= "Date is "+11+"/"+12+"/"+2000;
		assertEquals(s, date.toString());
	}
	
	@Test
	public void checkSetDayAndGetDay() {
		Date date = new Date(11, 12, 2000);
		assertEquals(11, date.getDay());
	}
	
	@Test
	public void checkSetMonthAndGetMonth() {
		Date date = new Date(11, 12, 2000);
		date.setMonth(10);
		assertEquals(10, date.getMonth());
	}

	@Test
	public void checksSetYearAndGetYear() {
		Date date = new Date(11, 12, 2000);
		date.setYear(2019);
		assertEquals(2019, date.getYear());
	}


}

