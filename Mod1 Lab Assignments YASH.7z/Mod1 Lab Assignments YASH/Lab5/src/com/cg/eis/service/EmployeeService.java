package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService 
{
	public String Display(Employee e);
	public String getInsuranceScheme(Employee e);

}
