package com.cp_yash.prgm2.bean;
public abstract class StringSpace implements IStringSpace {
		    public static void main(String[] args) {
			 
		    	IStringSpace e = (tring)->{ System.out.println(tring.replace(""," "));};
		    	e.space("hai");
		}
		    
}

