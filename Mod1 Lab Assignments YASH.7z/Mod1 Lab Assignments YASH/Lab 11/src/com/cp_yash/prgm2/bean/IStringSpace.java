package com.cp_yash.prgm2.bean;

public interface IStringSpace {
	
		public void space(String c);
		

	}

