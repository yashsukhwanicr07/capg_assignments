package com.cp_yash.prgm5.bean;

public interface IFact 
{
	  public void fact();
}


