package com.cp_yash.prgm5.bean;
import java.util.Scanner;

public class Fact implements IFact
{

		

			int f=1;
			public void fact()
			{
				System.out.println("Enter fact");
			    Scanner sc = new Scanner(System.in);
			    int num = sc.nextInt();
			    if(num>0 ){
			    for (int i =1;i<=num;i++) {
			    		f=f*i;
			    }
			    
			    }
			    else 
			    {
			    	System.out.println("1");
			    	}
			    	System.out.println(f);
			    }
			 public static void main(String[] args) 
			 {
			    	Fact e = new Fact();
			    	IFact ref = e::fact;//method reference
			        ref.fact();
			        
			 }
}

	
