package com.cp_yash.prgm3.bean;

public interface ILoginOperation 
{
	boolean login(String uname, String pass);

	}


