package com.cp_yash.prgm4.bean;

public interface IFuncInterface 
{ 
		public Simple methodDemo();

}

