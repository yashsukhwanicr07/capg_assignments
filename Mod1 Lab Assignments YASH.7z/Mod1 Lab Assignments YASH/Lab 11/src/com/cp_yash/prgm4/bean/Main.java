package com.cp_yash.prgm4.bean;

import java.util.Scanner;

public class Main 
{

		public static void main(String[] args) 
		{
		 Scanner sc=  new Scanner(System.in);
		 IFuncInterface obj =()->{
			 return new Simple();
		 };
		 Simple s = obj.methodDemo();
		 
		 System.out.println("Enter your firstname");
		 String fname = sc.nextLine();
		 
		System.out.println("Enter your lastname");
		String lname = sc.nextLine();

		s.setFname(fname);
		s.setLname(lname);

		System.out.println(s);
		}
}


