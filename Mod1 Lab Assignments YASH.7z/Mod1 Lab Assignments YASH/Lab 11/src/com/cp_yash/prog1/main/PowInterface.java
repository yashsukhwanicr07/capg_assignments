package com.cp_yash.prog1.main;

public interface PowInterface 
{
	public double power(double x,double y);
		
	}


