package com.cp_yash.prog1.main;

public interface FunctionalInterface {

	}

