package com.cp_yash.prgm2.bean;

public class MyException extends Exception 
{
	public MyException(String s) 
	{
		super(s);
	}
	
}
