package com.cp_yash.prgm1.bean;

public class MyException extends Exception 
{
	public MyException(String s) 
	{
		super(s);
	}
	
}