package com.cp_yash.prgm1.bean;

public class PersonMain {

	public static void main(String[] args) throws MyException
	{
			Person p1 = new Person("Bharti","Bharti", 'F');
			

	}

}