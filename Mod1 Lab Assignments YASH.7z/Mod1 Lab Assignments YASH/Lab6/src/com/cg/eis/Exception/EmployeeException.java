package com.cg.eis.Exception;

public class EmployeeException extends Exception 
{
	public EmployeeException(String s)
	{
		super(s);
	}
}