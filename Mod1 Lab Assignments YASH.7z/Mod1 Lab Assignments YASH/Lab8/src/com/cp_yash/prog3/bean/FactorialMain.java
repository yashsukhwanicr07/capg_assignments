package com.cp_yash.prog3.bean;

public class FactorialMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Fact obj1=new Fact();
     Fact obj2=new Fact();
     obj1.start();
     obj2.start();
	}

}