package com.cp_yash.prog2.bean;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Problem2 extends TimerTask {

    @Override
    public void run() {
        System.out.println("task begin at:"+new Date());
        completeTask();
    }

    private void completeTask() {
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String args[]){
        TimerTask timerTask = new Problem2();
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(timerTask, 0, 10*1000);
        System.out.println("Task began");
        try {
            Thread.sleep(120000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        timer.cancel();
        
        System.out.println("Task cancelled");
    }
}